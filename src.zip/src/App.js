import { Routes, Route, NavLink } from 'react-router-dom';
import VoteForm from './components/VoteForm';
import Resulst from './components/Results';

import './App.css';

function App() {
  return (
    <div className="max-w-3xl mx-auto p-4 text-center">
      <nav>
        <NavLink to='/' end className={({ isActive }) => isActive ? 'px-4 py-2 bg-blue-600 text-white rounded' : 'px-4 py-2 bg-gray-200 rounded'}>투표하기</NavLink>
        <NavLink to='/results' className={({ isActive }) => isActive ? 'ml-2 px-4 py-2 bg-blue-600 text-white rounded' : 'ml-2 px-4 py-2 bg-gray-200 rounded'}>결과보기</NavLink>
      </nav>

      <Routes>
        <Route path='/' element={<VoteForm />} />
        <Route path='/results' element={<Resulst />} />
      </Routes>
    </div>
  );
}

export default App;
